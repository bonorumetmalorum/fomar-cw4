all questions are contained within their own scope in the main function
all questions are in one cpp file
all output files will be in the "out" directory